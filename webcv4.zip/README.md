# React + TypeScript + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## Expanding the ESLint configuration

If you are developing a production application, we recommend updating the configuration to enable type-aware lint rules:

```js
export default tseslint.config([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      // Other configs...

      // Remove tseslint.configs.recommended and replace with this
      ...tseslint.configs.recommendedTypeChecked,
      // Alternatively, use this for stricter rules
      ...tseslint.configs.strictTypeChecked,
      // Optionally, add this for stylistic rules
      ...tseslint.configs.stylisticTypeChecked,

      // Other configs...
    ],
    languageOptions: {
      parserOptions: {
        project: ['./tsconfig.node.json', './tsconfig.app.json'],
        tsconfigRootDir: import.meta.dirname,
      },
      // other options...
    },
  },
])
```

You can also install [eslint-plugin-react-x](https://github.com/Rel1cx/eslint-react/tree/main/packages/plugins/eslint-plugin-react-x) and [eslint-plugin-react-dom](https://github.com/Rel1cx/eslint-react/tree/main/packages/plugins/eslint-plugin-react-dom) for React-specific lint rules:

```js
// eslint.config.js
import reactX from 'eslint-plugin-react-x'
import reactDom from 'eslint-plugin-react-dom'

export default tseslint.config([
  globalIgnores(['dist']),
  {
    files: ['**/*.{ts,tsx}'],
    extends: [
      // Other configs...
      // Enable lint rules for React
      reactX.configs['recommended-typescript'],
      // Enable lint rules for React DOM
      reactDom.configs.recommended,
    ],
    languageOptions: {
      parserOptions: {
        project: ['./tsconfig.node.json', './tsconfig.app.json'],
        tsconfigRootDir: import.meta.dirname,
      },
      // other options...
    },
  },
])
```

Para crear el proyecto:

```bash
npm create vite@latest webcv -- --template react-ts 
cd ./webcv/
```

Instalo dependencias

```bash
npm install
npm install tailwindcss @tailwindcss/vite
npm install react-router-dom
```

Componentes del navbar

```bash
npm install @headlessui/react
npm install @heroicons/react
```

Instalado componente de idiomas

```bash
npm install i18next react-i18next i18next-browser-languagedetector
```

Añadido en /src/main.tsx para poder traducir cualquier texto usando la notación {t(lorem ipsum)}

```typescript
import './i18n';
```

Instalado dependencia para manejar las traducciones en JSON:

```bash
npm install i18next-http-backend
```

Instalado dependencia de fontawesome

```bash
npm install @fortawesome/fontawesome-free
```

Instalado herramienta storybook

```bash
npx storybook@latest init
```

Story book 9.1.1

```bash
http://localhost:6006/?path=/story/example-page--logged-in&onboarding=false
```

Story book running tests 

```bash
npx vitest --project=storybook
```

Running storybook

```bash
npm run storybook
```

Configurar storybook con react

```bash
npm install storybook-addon-react-i18next
```